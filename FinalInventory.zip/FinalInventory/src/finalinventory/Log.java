/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class Log {
    public Integer LogID;
    public String EmpID;
    public String Fname;
    public String Lname;
    public String Status;
    public String Date;
    
    public Log(Integer id,String emp,String fname,String lname,String in,String out){
        this.LogID = id;
        this.EmpID = emp;
        this.Fname = fname;
        this.Lname = lname;
        this.Status = in;
        this.Date = out;
    }
    
    public Integer getID(){
        return LogID;
    }
    public String getEMP(){
        return EmpID;
    }
    public String getfname(){
        return Fname;
    }
    public String getlname(){
        return Lname;
    }
    public String getin(){
        return Status;
    }
    public String getout(){
        return Date;
    }
}
