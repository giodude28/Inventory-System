/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class Out {
    public Integer OutID;
    public String EmpID;
    public String StockID;
    public Integer InitialPail;
    public Integer InitialGalon;
    public Integer InitialLiter;
    public Integer InitialML;
    public Integer FinalPail;
    public Integer FinalGalon;
    public Integer FinalLiter;
    public Integer FinalML;
    public Integer OutPail;
    public Integer OutGalon;
    public Integer OutLiter;
        public Integer OutML;
    public String Date;
        public String ProductID;
    public String ProductBrand;
    public String ProductName;
    public String Fname;
    public String Lname;
    public String Status;
    
    public Out(Integer id,String emp,String sid,Integer ip,Integer ig,Integer il,Integer im,Integer fp,Integer fg,Integer fl,Integer fm,Integer op,Integer og,Integer ol,Integer om,String date,String pid,String brand,String name,String fname,String lname,String stat){
 this.OutID = id;
 this.EmpID = emp;
 this.StockID = sid;
 this.InitialPail  = ip;
  this.InitialGalon  = ig;
   this.InitialLiter  = il;
    this.InitialML  = im;
     this.FinalPail  = fp;
      this.FinalGalon  = fg;
       this.FinalLiter  = fl;
        this.FinalML  = fm;
         this.OutPail = op;
          this.OutGalon  = og;
           this.OutLiter  = ol;
            this.OutML  = om;
             this.Date  = date;
             this.ProductID = pid;
             this.ProductBrand = brand;
             this.ProductName = name;
             this.Fname = fname;
             this.Lname = lname;
             this.Status = stat;
    }
    public Integer getid(){
        return OutID;
    }
        public Integer getip(){
        return InitialPail;
    }
            public Integer getig(){
        return InitialGalon;
    }
                public Integer getil(){
        return InitialLiter;
    }
                    public Integer getim(){
        return InitialML;
    }
                        public Integer getfp(){
        return FinalPail;
    }
                            public Integer getfg(){
        return FinalGalon;
    }
                                public Integer getfl(){
        return FinalLiter;
    }
                                    public Integer getfm(){
        return FinalML;
    }
                                        public Integer getop(){
        return OutPail;
    }
                                            public Integer getog(){
        return OutGalon;
    }
                                                public Integer getol(){
        return OutLiter;
    }
                                                    public Integer getom(){
        return OutML;
    }
         public String getemp(){
             return EmpID;
         }                
         public String getsid(){
             return StockID;
         }
         public String getdate(){
             return Date;
         }
                  public String getpid(){
             return ProductID;
         }
                           public String getbrand(){
             return ProductBrand;
         }
                                    public String getname(){
             return ProductName;
         }
                                                               public String getfname(){
             return Fname;
         }
                                    public String getlname(){
             return Lname;
         }
                                    public String getstat(){
                                        return Status;
                                    }
}
