/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author JustinAuditore
 */
public class ReportProduct {
   private String ProductID;
   private String ProductBrand;
   private String ProductName;
   private Integer Pail;
   private Integer Galon;
   private Integer Liter;
   private Integer ML;
    
    public ReportProduct (String id, String brand,String name,Integer pa,Integer ga,Integer li,Integer ma)
    {

        this.ProductID = id;
        this.ProductBrand = brand;
        this.ProductName = name;
        this.Pail = pa;
        this.Galon = ga;
        this.Liter = li;
        this.ML = ma;

    }

    public String getID(){
        return ProductID;
    }
    public String getbrand(){
        return ProductBrand;
    }
        public String getname(){
        return ProductName;
    }
        public Integer getpa(){
        return Pail;
    }        
        public Integer getga(){
        return Galon;
    }
        public Integer getli(){
        return Liter;
    }
        public Integer getma(){
        return ML;
    }        
}
