/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author JustinAuditore
 */
public class user {
    public String EmpID;
    public String Fname;
    public String Lname;
    public String Username;
    public String Status;
    
    public user(String emp,String fname,String lname,String un,String st){
        this.EmpID = emp;
        this.Fname = fname;
        this.Lname = lname;
        this.Username = un;
        this.Status = st;
    }
    
    public String getID(){
        return EmpID;
    }
    public String getfname(){
        return Fname;
    }
    public String getlname(){
        return Lname;
    }
    public String getUn(){
        return Username;
    }
    public String getst(){
        return Status;
    }
}
