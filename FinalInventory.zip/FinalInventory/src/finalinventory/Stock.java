/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class Stock {
    private String StockID;
    private String ProductID;
    private String ProductBrand;
    private String ProductName;
    private Integer Pail;
    private Integer Galon;
    private Integer Liter;
    private Integer ml;
    private String DateExpired;
    
    public Stock (String stock, String id, String brand,String name, int pail, int galon, int liter,int ML,String expired)
    {
        this.StockID = stock;
        this.ProductID = id;
        this.ProductBrand = brand;
        this.ProductName = name;
        this.Pail = pail;
        this.Galon = galon;
        this.Liter = liter;
        this.ml = ML;
        this.DateExpired = expired;
    }
    public String getstock(){
        return StockID;
    }
    public String getID(){
        return ProductID;
    }
    public String getbrand(){
        return ProductBrand;
    }
        public String getname(){
        return ProductName;
    }
    public Integer getpail(){
        return Pail;
    }
    public Integer getGal(){
        return Galon;
    }
    public Integer getLit(){
        return Liter;
    }
    public Integer getML(){
        return ml;
    }
            public String getEx(){
        return DateExpired;
    }
}
