/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class In {
    public Integer AddID;
    public String EmpID;
    public String Fname;
    public String Lname;
    public String StockID;
    public String ProductID;
    public String Pail;
    public String Liter;
    public String Galon;
    public String ML;
    public String DateCreated;
    public String ProductBrand;
    public String ProductName;
    
    public In(Integer id,String emp,String fname,String lname,String sid,String pid,String pail,String liter,String galon,String ml,String date,String brand,String name){
    this.AddID = id;
this.EmpID = emp;
this.Fname = fname;
this.Lname = lname;
this.StockID = sid;
this.ProductID = pid;
this.Pail = pail;
this.Liter = liter;
this.Galon = galon;
this.ML = ml;
this.DateCreated = date;
this.ProductBrand = brand;
this.ProductName = name;
    }
    public Integer getid(){
        return AddID;
    }
    
    public String getemp(){
        return EmpID;
    }
    
    public String getfname(){
        return Fname;
    }
    
    public String getlname(){
        return Lname;
    }
    
    public String getsid(){
        return StockID;
    }
    public String getpid(){
        return ProductID;
    }
    
    public String getpail(){
        return Pail;
    }
    
    public String getliter(){
        return Liter;
    }
    
    public String getgalon(){
        return Galon;
    }
    
    public String getml(){
        return ML;
    }
        public String getdate(){
        return DateCreated;
    }
            public String getbrand(){
        return ProductBrand;
    }
                public String getname(){
        return ProductName;
    }
    
    
}
