/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class MinusRaw {
    private String RawStockID;
    private Integer RawID;
    private String Quantity;
    private String Name;
    private String Unit;
    private String DateEntry;
    
    public MinusRaw (String id, Integer raw,String quan,String name,String unit,String date)
    {
        this.RawID = raw;
        this.Name = name;
        this.Unit = unit;
        this.DateEntry = date;
        this.Quantity = quan;
        this.RawStockID = id;
    }

    public String getID(){
        return RawStockID;
    }
     public Integer getIDD(){
        return RawID;
    }
         public String getquan(){
        return Quantity;
    }
    public String getname(){
        return Name;
    }
    public String getunit(){
        return Unit;
    }
        public String getdate(){
        return DateEntry;
    }
}
