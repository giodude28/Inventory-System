/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author Earl
 */
public class EmpClassConUrl {
                public String conUrl () throws ClassNotFoundException {
        
        Class.forName("com.mysql.jdbc.Driver");//Palitan ng IP ng server yung localhost
        String connectionUrl = "jdbc:mysql://192.168.1.10:3306/finalinventory?" + "user=root&password=";
        
        return connectionUrl;
    } 
}
