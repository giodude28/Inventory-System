/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author Earl
 */
public class Custodial {
     private String CID;
    private String CName;
    private Integer Price;
    private String UnitMeasurement;

    
    public Custodial (String id, String name,Integer price,String unit)
    {

        this.CID = id;
        this.CName = name;
        this.Price = price;
        this.UnitMeasurement = unit;

    }

    public String getID(){
        return CID;
    }
    public String getbrand(){
        return CName;
    }
        public Integer getname(){
        return Price;
    }
        public String getsize(){
        return UnitMeasurement;
    }
}
