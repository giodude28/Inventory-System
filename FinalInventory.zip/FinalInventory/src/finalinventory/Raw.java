/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class Raw {
    private Integer RawID;
    private String RawName;
    private String Unitsize;
    private String Status;

    
    public Raw (int raw, String name, String size,String stat)
    {
        this.RawID = raw;
        this.RawName = name;
        this.Unitsize = size;
        this.Status = stat;

    }
    public Integer getID(){
        return RawID;
    }
        public String getname(){
        return RawName;
    }
    public String getsize(){
        return Unitsize;
    }
    public String getstat(){
        return Status;
    }
}
