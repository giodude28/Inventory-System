/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class InAudit extends javax.swing.JFrame {

    /**
     * Creates new form ProductTable
     */
    int awd = 0;
    public InAudit() throws ClassNotFoundException, SQLException {
        initComponents();
        findUsersTable();
        findUsers();
        Seticon();
    }
    

     public ArrayList<In> ListUsers(String ValToSearch)throws ClassNotFoundException, SQLException
    {
        ArrayList<In> userList = new ArrayList<In>();
  
              ClassConUrl cUrl = new ClassConUrl();
        String connectionUrl = cUrl.conUrl();
        Connection con = DriverManager.getConnection(connectionUrl);
            String searchQuery = "SELECT b.AddID,a.EmpID,a.Fname,a.Lname,c.StockID,c.ProductID,b.Pail,b.Galon,b.Liter,b.ML,c.DateCreated,d.ProductBrand,d.ProductName FROM usertbl a INNER JOIN  inaudit b ON a.EmpID = b.EmpID INNER JOIN stocktbl c ON b.StockID = c.StockID INNER JOIN producttbl d ON c.ProductID = d.ProductID WHERE a.Fname LIKE '%"+ValToSearch+"%'";
try{  
           PreparedStatement prest= con.prepareStatement(searchQuery);
           ResultSet rs = prest.executeQuery();
            In stock;
            while(rs.next())
            {
                   stock = new In (
                            rs.getInt("AddID"),
                rs.getString("EmpID"),
                           rs.getString("Fname"),
                rs.getString("Lname"),
                           rs.getString("StockID"),
                           rs.getString("ProductID"),
                           rs.getString("Pail"),
                           rs.getString("Liter"),
                           rs.getString("Galon"),
                           rs.getString("ML"),
                           rs.getString("DateCreated"),
                           rs.getString("ProductBrand"),
                           rs.getString("ProductName")
                );
                userList.add(stock);
            }
      
    } catch (Exception e) {
           e.printStackTrace();
       }  
        return userList;
    }
     public ArrayList<In> ListUsersTable()throws ClassNotFoundException, SQLException
    {
        ArrayList<In> userList = new ArrayList<In>();
  
              ClassConUrl cUrl = new ClassConUrl();
        String connectionUrl = cUrl.conUrl();
        Connection con = DriverManager.getConnection(connectionUrl);
            String searchQuery = "SELECT b.AddID,a.EmpID,a.Fname,a.Lname,c.StockID,c.ProductID,b.Pail,b.Galon,b.Liter,b.ML,c.DateCreated,d.ProductBrand,d.ProductName FROM usertbl a INNER JOIN  inaudit b ON a.EmpID = b.EmpID INNER JOIN stocktbl c ON b.StockID = c.StockID INNER JOIN producttbl d ON c.ProductID = d.ProductID";
            try{  
           PreparedStatement prest= con.prepareStatement(searchQuery);
           ResultSet rs = prest.executeQuery();
            In stock;
            while(rs.next())
            {
                   stock = new In (
                           rs.getInt("AddID"),
                rs.getString("EmpID"),
                           rs.getString("Fname"),
                rs.getString("Lname"),
                           rs.getString("StockID"),
                           rs.getString("ProductID"),
                           rs.getString("Pail"),
                           rs.getString("Liter"),
                           rs.getString("Galon"),
                           rs.getString("ML"),
                           rs.getString("DateCreated"),
                           rs.getString("ProductBrand"),
                           rs.getString("ProductName")
                );
                userList.add(stock);
            }
      
    } catch (Exception e) {
           e.printStackTrace();
       }
        return userList;
    }
     public void findUsers()throws ClassNotFoundException, SQLException
    {
        ArrayList<In> users = ListUsers(jTextField1.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"EmpID","Fname","Lname","StockID","Product Brand","Product Name","Pail","Gallon","Liter","ML","Date"});
        Object[] row = new Object[11];
        for(int i =0; i <users.size(); i++)
        {
            row[0] = users.get(i).getemp();
            row[1] = users.get(i).getfname();
            row[2] = users.get(i).getlname();
            row[3] = users.get(i).getsid();
            row[4] = users.get(i).getbrand();
            row[5] = users.get(i).getname();
            row[6] = users.get(i).getpail();
            row[7] = users.get(i).getgalon();
            row[8] = users.get(i).getliter();
            row[9] = users.get(i).getml();
            row[10] = users.get(i).getdate();
            model.addRow(row);
        }
        jTable1.setModel(model);
    }
      public void findUsersTable()throws ClassNotFoundException, SQLException
    {
        ArrayList<In> users = ListUsersTable();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"EmpID","Fname","Lname","StockID","Product Brand","Product Name","Pail","Gallon","Liter","ML","Date"});
        Object[] row = new Object[11];
        for(int i =0; i <users.size(); i++)
        {
            row[0] = users.get(i).getemp();
            row[1] = users.get(i).getfname();
            row[2] = users.get(i).getlname();
            row[3] = users.get(i).getsid();
            row[4] = users.get(i).getbrand();
            row[5] = users.get(i).getname();
            row[6] = users.get(i).getpail();
            row[7] = users.get(i).getgalon();
            row[8] = users.get(i).getliter();
            row[9] = users.get(i).getml();
            row[10] = users.get(i).getdate();
            model.addRow(row);
        }
        jTable1.setModel(model);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Product Stock Audit");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 220, 714, 324));

        jTextField1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 150, 230, 50));

        jButton1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/finalinventory/images/icons8_Go_Back_48px_1.png"))); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 30, -1, -1));

        jButton4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/finalinventory/images/icons8_Search_48px.png"))); // NOI18N
        jButton4.setText("Search");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 150, -1, 50));

        jPanel2.setBackground(new java.awt.Color(0, 51, 153));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 330, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 620, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, 620));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1146, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
AdminMain tae = new AdminMain();
tae.setVisible(true);
this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            findUsers();        // TODO add your handling code here:
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InAudit.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(InAudit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InAudit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InAudit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InAudit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InAudit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new InAudit().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(InAudit.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(InAudit.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }private void Seticon(){
    setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("HI logo.png")));
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
