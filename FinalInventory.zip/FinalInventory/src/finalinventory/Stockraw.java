/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class Stockraw {
    private String StockID;
    private Integer RawID;
    private String Name;
    private Integer Stocks;
    private String Unit;
    
    public Stockraw (String idd,Integer id, String name, int stock,String unit)
    {
        this.StockID = idd;
        this.RawID = id;
        this.Name = name;
        this.Stocks = stock;
        this.Unit = unit;
    }
    public String getIDD(){
        return StockID;
    }
    public Integer getID(){
        return RawID;
    }
    public String getname(){
        return Name;
    }
    public Integer getstock(){
        return Stocks;
    }
    public String getunit(){
        return Unit;
    }
}
