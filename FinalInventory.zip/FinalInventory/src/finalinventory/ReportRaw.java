/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author JustinAuditore
 */
public class ReportRaw {
   private String RawID;
   private String RawName;
   private String UnitSize;
   private Integer Quantity;

    
    public ReportRaw (String id, String brand,String size,Integer qty)
    {

        this.RawID = id;
        this.RawName = brand;
        this.UnitSize = size;
        this.Quantity = qty;


    }

    public String getID(){
        return RawID;
    }
    public String getname(){
        return RawName;
    }
        public String getsize(){
        return UnitSize;
    }
        public Integer getqty(){
        return Quantity;
    }        
   
}
