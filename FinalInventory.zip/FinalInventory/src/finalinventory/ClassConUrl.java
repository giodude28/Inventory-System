/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class ClassConUrl {
            public String conUrl () throws ClassNotFoundException {
        
        Class.forName("com.mysql.jdbc.Driver");
        String connectionUrl = "jdbc:mysql://localhost:3306/finalinventory?" + "user=root&password=";
        
        return connectionUrl;
    } 
}
