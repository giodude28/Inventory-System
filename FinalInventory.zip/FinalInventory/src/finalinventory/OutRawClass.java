/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class OutRawClass {
    public Integer RawOutID;
    public String EmpID;
    public String RawStockID;
    public Integer InitialRaw;
    public Integer FinalRaw;
    public Integer OutRaw;
    public String Date;
    public String RawName;
    public String Fname;
    public String Lname;
    public String Status;
    
    public OutRawClass(Integer id,String emp,String sid,Integer ir,Integer fr,Integer or,String date,String name,String fname,String lname,String stat){
 this.RawOutID = id;
 this.EmpID = emp;
 this.RawStockID = sid;
 this.InitialRaw  = ir;
     this.FinalRaw  = fr;
         this.OutRaw = or;
             this.Date  = date;
             this.RawName = name;
             this.Fname = fname;
             this.Lname = lname;
             this.Status = stat;
    }
    public Integer getid(){
        return RawOutID;
    }
        public Integer getir(){
        return InitialRaw;
    }
                        public Integer getfr(){
        return FinalRaw;
    }
                                public Integer getor(){
        return OutRaw;
    }
         public String getemp(){
             return EmpID;
         }                
         public String getsid(){
             return RawStockID;
         }
         public String getdate(){
             return Date;
         }
                                    public String getname(){
             return RawName;
         }
                                                               public String getfname(){
             return Fname;
         }
                                    public String getlname(){
             return Lname;
         }
                                    public String getstat(){
                                        return Status;
                                    }
}
