/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author Earl
 */
public class custodialstock {
      private String StockID;
    private String ProductID;
    private String ProductName;
    private Integer Quantity;
    private String DateEntry;
    
    public custodialstock (String stock, String id,String name, int pail,String expired)
    {
        this.StockID = stock;
        this.ProductID = id;
        this.ProductName = name;
        this.Quantity = pail;
        this.DateEntry = expired;
    }
    public String getstock(){
        return StockID;
    }
    public String getID(){
        return ProductID;
    }
        public String getname(){
        return ProductName;
    }
    public Integer getpail(){
        return Quantity;
    }
            public String getEx(){
        return DateEntry;
    }
}
