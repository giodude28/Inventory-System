/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class DeleteRetrieve {
    private String ProductID;
    private String ProductBrand;
    private String ProductName;
    private String Status;
    
    public DeleteRetrieve (String id,String brand, String name,String stat)
    {
        this.ProductID = id;
        this.ProductBrand = brand;
        this.ProductName = name;
        this.Status = stat;
    }
    public String getID(){
        return ProductID;
    }
    public String getbrand(){
        return ProductBrand;
    }
    public String getname(){
        return ProductName;
    }
    public String getStat(){
        return Status;
    }
}
