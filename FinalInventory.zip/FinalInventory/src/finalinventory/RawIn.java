/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class RawIn {
    public Integer RawIn;
    public String EmpID;
    public String RawStockID;
    public String Fname;
    public String Lname;
    public String RawID;
    public String Quantity;
    public String DateEntry;
    public String RawName;
    
    public RawIn(Integer in,String emp,String sid,String fname,String lname,String rid,String quan,String date,String name){
        this.RawIn = in;
        this.EmpID = emp;
        this.Fname = fname;
        this.Lname = lname;
        this.RawStockID = sid;
        this.RawID = rid;
        this.Quantity = quan;
        this.DateEntry = date;
        this.RawName = name;        
    }
    
    public Integer getin(){
        return RawIn;
    }
    public String getemp(){
        return EmpID;
    }
    
    public String getfname(){
        return Fname;
    }
    
    public String getlname(){
        return Lname;
    }
    
    public String getsid(){
        return RawStockID;
    }
    
    public String getrid(){
        return RawID;
    }
    
    public String getquan(){
        return Quantity;
    }
        public String getdate(){
        return DateEntry;
    }
            public String getname(){
        return RawName;
    }
    
}
