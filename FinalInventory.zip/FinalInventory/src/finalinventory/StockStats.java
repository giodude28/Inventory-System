/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class StockStats {
    private String ProductID;
    private String Name;
    private Integer Pail;
    private Integer Galon;
    private Integer Liter;
    private Integer ML;
    private String Status;
    
    public StockStats (String id, String name, int pail, int galon, int liter,int ML,String stat)
    {
        this.ProductID = id;
        this.Name = name;
        this.Pail = pail;
        this.Galon = galon;
        this.Liter = liter;
        this.ML = ML;
        this.Status = stat;
    }
    public String getID(){
        return ProductID;
    }
    public String getname(){
        return Name;
    }
    public Integer getpail(){
        return Pail;
    }
    public Integer getGal(){
        return Galon;
    }
    public Integer getLit(){
        return Liter;
    }
    public Integer getML(){
        return ML;
    }
    public String getStat(){
        return Status;
    }
}
