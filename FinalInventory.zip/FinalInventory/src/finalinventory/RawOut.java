/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class RawOut {
    public Integer RawOutID;
    public String EmpID;
    public String RawStockID;
    public Integer InitialRawStock;
    public Integer OutRawStock;
    public Integer FinalRawStock;
    public String Date;
    public String RawName;
    public String Fname;
    public String Lname;
    
    public RawOut(Integer id,String emp,String rsid,Integer ir,Integer or,Integer fr,String date,String rname,String fname,String lname){
this.RawOutID = id;
this.EmpID = emp;
this.RawStockID = rsid;
this.InitialRawStock = ir;
this.OutRawStock = or;
this.FinalRawStock = fr;
this.Date =date;
this.RawName = rname;
this.Fname = fname;
this.Lname = lname;
    }
    
    public Integer getid(){
        return RawOutID;
    }
    public String getemp(){
        return EmpID;
    }
    public String getrsid(){
        return RawStockID;
    }
    public Integer getir(){
        return InitialRawStock;
    }
    
    public Integer getor(){
        return OutRawStock;
    }
    
    public Integer getfr(){
        return FinalRawStock;
    }
        public String getdate(){
        return Date;
    }
            public String getrname(){
        return RawName;
    }
                public String getfname(){
        return Fname;
    }
                    public String getlname(){
        return Lname;
    }
}
