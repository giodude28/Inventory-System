/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalinventory;

/**
 *
 * @author user
 */
public class DeleteRetrieveCustodial {
    private String CID;
    private String CName;
    private String Status;
    
    public DeleteRetrieveCustodial (String id, String name,String stat)
    {
        this.CID = id;
        this.CName = name;
        this.Status = stat;
    }
    public String getID(){
        return CID;
    }
    public String getname(){
        return CName;
    }
    public String getStat(){
        return Status;
    }
}
